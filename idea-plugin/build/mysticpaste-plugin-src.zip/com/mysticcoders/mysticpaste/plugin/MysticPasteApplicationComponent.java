/*
 * Created by IntelliJ IDEA.
 * User: kinabalu
 * Date: Mar 29, 2009
 * Time: 8:09:27 PM
 */
package com.mysticcoders.mysticpaste.plugin;

import com.intellij.openapi.components.ApplicationComponent;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class MysticPasteApplicationComponent implements ApplicationComponent {

    /**
     * Method is called after plugin is already created and configured. Plugin can start to communicate with
     * other plugins only in this method.
     */
    public void initComponent() {
        System.out.println("SampleApplicationPlugin: initComponent");
    }

    /**
     * This method is called on plugin disposal.
     */
    public void disposeComponent() {
        System.out.println("SampleApplicationPlugin: disposeComponent");
    }

    /**
     * Returns the name of component
     *
     * @return String representing component name. Use plugin_name.component_name notation.
     */
    @NotNull
    public String getComponentName() {
        return "MysticPastePlugin.MysticPasteApplicationComponent";
    }

}
